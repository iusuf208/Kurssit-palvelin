const express = require("express");
const fs = require("fs-extra");
const csv = require("csv-parser");
const path = require("path");

const app = express();
const PORT = 3000;

const CSV_FILE = "kurssit.csv";
const JSON_FILE = "kurssit.json";

app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static("views"));

let kurssidata = [];


function lataaCSV() {
  return new Promise((resolve, reject) => {
    const data = [];
    fs.createReadStream(CSV_FILE)
      .pipe(csv())
      .on("data", (row) => data.push(row))
      .on("end", () => {
        kurssidata = data;
        fs.writeJsonSync(JSON_FILE, data, { spaces: 2 });
        console.log("CSV ladattu ja JSON tallennettu.");
        resolve();
      })
      .on("error", reject);
  });
}




app.get("/api/kaikki", (req, res) => res.json(kurssidata));

app.get("/api/kurssi/:nimi", (req, res) => {
  const tulokset = kurssidata.filter((k) => k.kurssi === req.params.nimi);
  tulokset.length
    ? res.json(tulokset)
    : res.json({ viesti: "Kurssia ei löytynyt" });
});

app.get("/api/opiskelija/:nimi", (req, res) => {
  const tulokset = kurssidata.filter((k) => k.opiskelija === req.params.nimi);
  tulokset.length
    ? res.json(tulokset)
    : res.json({ viesti: "Opiskelijaa ei löytynyt" });
});


app.get("/api/arvosana/:opiskelija/:kurssi", (req, res) => {
  const { opiskelija, kurssi } = req.params;
  const tulos = kurssidata.find(
    (k) => k.opiskelija === opiskelija && k.kurssi === kurssi
  );
  tulos ? res.json(tulos) : res.json({ viesti: "Ei löytynyt" });
});


app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "views", "haku.html"));
});


lataaCSV().then(() => {
  app.listen(PORT, () =>
    console.log(`Palvelin käynnissä: http://localhost:${PORT}`)
  );
});
